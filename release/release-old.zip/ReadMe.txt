This is a backup of old release in case that
something will go wrong after refactoring
